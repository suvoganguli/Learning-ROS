Class MoveBB8:
    def fun_move_bb8(self):
        None
        
    def do_print(self):
    print("called MoveB88.py")
    
    