#! /usr/bin/env python

import rospy
from iri_wam_reproduce_trajectory.srv import ExecTraj, ExecTrajRequest
import sys 

rospy.init_node('service_exectraj_client') # Initialise a ROS node with the name service_client
rospy.wait_for_service('/execute_trajectory') # Wait for the service client /execute_trajectory to be running

# to get the next command:
# > roslaunch unit_3_services my_robot_arm_demo.launch
#
# in another window
# > rosservice list | grep execute_trajectory
# > rosservice info /execute_trajectory
#
# This tells us that if we have to call the service execute_trajectory, 
# we will need to use the service message type ExecTraj from package 
# iri_wam_reproduce_trajectory.

exectraj_service_client = rospy.ServiceProxy('/execute_trajectory', ExecTraj) # Create the connection to the service

exectraj_request_object = ExecTrajRequest()
exectraj_request_object.file = "../config/release_food.txt"

result = exectraj_service_client(exectraj_request_object) # Send through the connection the path to the trajectory file to be executed
print result