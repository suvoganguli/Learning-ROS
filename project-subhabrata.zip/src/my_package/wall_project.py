#! /usr/bin/env python

# get information about laser topic
# rostopic list | grep laser
#
# get the python package info using:
# rostopic info /kobuki/laser/scan
#
# get the fields of LaserScan using:
# rosmsg show sensor_msgs/LaserScan

import rospy
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist 
import numpy as np

angle = 0.0
del_t = 0.1
stop_rotate = 0

def callback(msg):

  # if dist in front > 1.0 m, go straight
  if msg.ranges[360] > 1.0:
    vel_msg.linear.x = 1.0
    vel_msg.angular.z = 0
  
  # if dist in front < 1.0 m, turn left
  if msg.ranges[360] <= 1.0:
    vel_msg.linear.x = 0.0
    vel_msg.angular.z = 90*np.pi/180
    
  # if dist in right > 1.0, turn right
  if msg.ranges[719] < 0.9:
    vel_msg.linear.x = 1.0
    vel_msg.angular.z = 0*np.pi/180
  
  pub.publish(vel_msg)

rospy.init_node('move_robot_pub')
pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
sub = rospy.Subscriber('/kobuki/laser/scan',LaserScan,callback)

vel_msg = Twist()
rospy.spin()