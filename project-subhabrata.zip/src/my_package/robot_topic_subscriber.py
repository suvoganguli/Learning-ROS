#! /usr/bin/env python

#rosmsg show nav_msgs/Odometry

import rospy
from nav_msgs.msg import Odometry 
# note:
# rostopic list --> /odom
# rostopic info /odom --> nav_msgs/Odometry

rospy.init_node('robot_topic_subscriber')

def callback(msg):
  #print msg
  #print msg.header
  print msg.pose
  
sub = rospy.Subscriber('/odom',Odometry,callback)

rospy.spin()

# to see, run the following in a different window:
# > roslaunch my_package robot_move_launch_file.launch
# in this window, run 
# > python ros_subsriber.py