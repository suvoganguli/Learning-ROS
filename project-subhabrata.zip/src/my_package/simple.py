#! /usr/bin/env python

import rospy

rospy.init_node("ObiWan")

print("Help me Obiwan")
